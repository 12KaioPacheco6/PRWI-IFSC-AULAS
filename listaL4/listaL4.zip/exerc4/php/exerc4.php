<!DOCTYPE html>
<html lang="pt-BR">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title> Fundamentos da linguagem PHP </title>
 <link rel="stylesheet" href="../css/formata-pagina.css">
</head>

<body>
 <h1> Vetores em PHP - listaL4 - Exercício 3 </h1>
 <?php
  
  $aluno1 = $_POST['aluno1'];
  $aluno2 = $_POST['aluno2'];
  $aluno3 = $_POST['aluno3'];

  $matric1 = $_POST['matric1'];
  $matric2 = $_POST['matric2'];
  $matric3 = $_POST['matric3'];

  $media1= $_POST['media1'];
  $media2= $_POST['media2'];
  $media3= $_POST['media3'];

  //criando a matriz em PHP: a matricula será o indice I da matriz 
  $matrizAlunos = [$matric1 => [$aluno1, $media1], $matric2 => [$aluno2, $media2], $matric3 => [$aluno3, $media3]];

  //para encontrar o aluno pesquisado na matriz, começamos recebendo o seu nome do fórmulario 
  $alunoPesquisado = $_POST['pesquisa-aluno'];

  $encotrou = false;

  //vamos percorrer, com o foreach, a matriz, a perguntar ao PHP se ele encontrou o aluno pesquisado
  foreach($matrizAlunos as $matric => $vetorInterno)
  {
    if($alunoPesquisado == $vetorInterno[0])
    {
      $encontrou = true;
      $matriculaAlunoPesquisada = $matric;
      $mediaFinal = $vetorInterno[1];
    }
  }

  if ($encontrou == true) 
  {
    echo "<p> Dados do Aluno pesquisado: <br> 
              Nome: <span> $alunoPesquisado </span> <br>
              Matrícula: <span> $matriculaAlunoPesquisada </span> <br> 
              Média do Aluno: <span> $mediaFinal </span> </p>";
  }
  else 
  {
    echo " <p> O aluno com o nome pesquisado: <span> $alunoPesquisado </span> não está cadastrado na Matriz! </p>";
  }
 ?> 
</body>
</html>